---
date: 2020-05-26 21:17:12
layout: links
title: 我的小伙伴们
keywords: 链接
description: 云游的小伙伴们
comments: false
links:
  - url: https://yunyoujun.cn
    avatar: https://cdn.jsdelivr.net/gh/YunYouJun/yunyoujun.github.io/images/avatar.jpg
    name: 云游君
    blog: 云游君的小站
    desc: All at sea.
    color: "#0078e7" # 代表色
    email: # 非必须
  - url: https://ruyucc.github.io
    avatar: https://weixizi.oss-cn-hangzhou.aliyuncs.com/bolg/QQ%E5%9B%BE%E7%89%8720200527095056.jpg
    name: 如玉CC
    blog: 如玉CC的小站
    desc: All at sea.
    color: "#EEE8AA" # 代表色
    email: # 非必须
placeholder: 还没想好说些什么 # 默认对友链的描述
tip: 友链加载中～如失败请刷新重试～
---
